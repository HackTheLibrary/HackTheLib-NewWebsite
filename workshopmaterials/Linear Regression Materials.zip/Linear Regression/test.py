#This script and more in depth explanations can be found at: https://www.youtube.com/watch?v=Hj8NZVXFr8Q&feature=youtu.be

#Import all of these libraries
import pandas as pd
import numpy as np
import sklearn
from sklearn import linear_model
from sklearn.utils import shuffle
import tensorflow
import keras
import matplotlib.pyplot as pyplot
import pickle
from matplotlib import style

data = pd.read_csv("Linear Regression/student-mat.csv", sep=";")#Seperate data on commas

data = data[["G1", "G2", "G3", "studytime", "failures", "absences"]]#attributes
print(data.head())#Printing the data frame
predict = "G3"
#Seperating our data into labels & feautures
x = np.array(data.drop([predict], 1))#Feature-other attributed which determine the label
y = np.array(data[predict])#Label-the attribute we are predicting
x_train, x_test, y_train, y_test = sklearn.model_selection.train_test_split(x,y, test_size=0.1)#Splitting our training and testing data! This is key! This line allocates 90% of data to be trained and other 10% for testing purposes

#Below is code you can un-comment if you would like
#Below is an example of training our model multiple times in order to get the highest accuracy score
#I was able to get around 96% so I did not go any further, feel free to mess around and get a higher accuracy!
# bestScore = 0;
# for _ in range(500):
#     x_train, x_test, y_train, y_test = sklearn.model_selection.train_test_split(x,y, test_size=0.1)
#
#     linear = linear_model.LinearRegression()
#
#     linear.fit(x_train, y_train)
#
#     accuracy = linear.score(x_test, y_test)#Get the accuracy of the model on testing data
#
#     print(accuracy)
#
# If the current model has a better score than one we've already trained then save it
#     if accuracy > bestScore:
#         bestScore = accuracy
            #The lines below allow us to save our model into our local directory or wherever you specify
#         with open("studentmodel.pickle", "wb") as f:
#             pickle.dump(linear,f)#create pickle file

pickle_in = open("Linear Regression/studentmodel.pickle", "rb")#Pre trained model is being loaded in using the pickle module

linear = pickle.load(pickle_in)#Linear is the mode name, just assigining it to the pre-trained one we already have

print("Co: ", linear.coef_)#Slope value
print("Intercept: ", linear.intercept_)#Y-intercept

predictions = linear.predict(x_test)

# for x in range (len(predictions)):
#     print(predictions[x], x_test[x], y_test[x])

#Using the matplot lib library in order to make a nice scatter plot. This way we can visualize all the correlations between our data.
p = "absences"
style.use("ggplot")
pyplot.scatter(data[p], data["G3"])
pyplot.xlabel(p)
pyplot.ylabel("Final Grade (3rd Trimester)")
pyplot.show()
